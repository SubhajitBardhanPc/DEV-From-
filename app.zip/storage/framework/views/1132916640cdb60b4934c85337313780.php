<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admit Card</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Admit Card</h2>
        <p class="text-center">Here are your exam details:</p>

        <!-- Display user data -->
        <div class="card">
            <div class="card-body">
                <h4>Name: <?php echo e($user->name); ?></h4>
                <p><strong>Father's Name:</strong> <?php echo e($user->father_name); ?></p>
                <p><strong>Mother's Name:</strong> <?php echo e($user->mother_name); ?></p>
                <p><strong>Gender:</strong> <?php echo e($user->gender); ?></p>
                <p><strong>College Name:</strong> <?php echo e($user->college_name); ?></p>
                <p><strong>University Name:</strong> <?php echo e($user->university_name); ?></p>
                <p><strong>State:</strong> <?php echo e($user->state); ?></p>
                <p><strong>City:</strong> <?php echo e($user->city); ?></p>
                <p><strong>Department:</strong> <?php echo e($user->department); ?></p>
                <p><strong>Date of Birth:</strong> <?php echo e($user->dob); ?></p>

                <!-- Display image and signature -->
                <div>
                    <img src="<?php echo e(Storage::url($user->image)); ?>" alt="User Image" class="img-thumbnail" width="150">
                    <img src="<?php echo e(Storage::url($user->signature)); ?>" alt="User Signature" class="img-thumbnail" width="150">
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\subha\Desktop\Form\Forms Fill\form-fillup-project\resources\views/admitCard.blade.php ENDPATH**/ ?>