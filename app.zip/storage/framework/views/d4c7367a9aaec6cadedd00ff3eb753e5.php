<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>From</title>
</head>
<body>
    <!-- resources/views/gate_form.blade.php -->

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<form action="<?php echo e(route('gate-form.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div>
        <label for="student_name">Student Name</label>
        <input type="text" name="student_name" id="student_name" required>
    </div>

    <div>
        <label for="father_name">Father's Name</label>
        <input type="text" name="father_name" id="father_name" required>
    </div>

    <div>
        <label for="mother_name">Mother's Name</label>
        <input type="text" name="mother_name" id="mother_name" required>
    </div>

    <div>
        <label for="phone">Phone Number</label>
        <input type="text" name="phone" id="phone" required>
    </div>

    <div>
        <label for="email">Email</label>
        <input type="email" name="email" id="email" required>
    </div>

    <div>
        <label for="gender">Gender</label>
        <select name="gender" id="gender" required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select>
    </div>

    <!-- Add other fields as needed -->

    <div>
        <button type="submit">Submit</button>
    </div>
</form>


</body>
</html><?php /**PATH C:\Users\subha\Desktop\Form\Forms Fill\form-fillup-project\resources\views/gate_form.blade.php ENDPATH**/ ?>